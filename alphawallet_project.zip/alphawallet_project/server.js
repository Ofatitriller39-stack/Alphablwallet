import express from 'express';
import fs from 'fs';
import path from 'path';
import bodyParser from 'body-parser';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '10mb' }));

const USERS_FILE = path.join(process.cwd(), 'users.json');

function ensureUsersFile(){
  if(!fs.existsSync(USERS_FILE)){
    fs.writeFileSync(USERS_FILE, '[]', 'utf-8');
  }
}
function readUsers(){
  ensureUsersFile();
  try{
    const raw = fs.readFileSync(USERS_FILE, 'utf-8');
    return JSON.parse(raw || '[]');
  }catch(e){
    return [];
  }
}
function writeUsers(users){
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
}

// Serve static frontend
const publicDir = path.join(process.cwd(), 'public');
if(fs.existsSync(publicDir)){
  app.use(express.static(publicDir));
}

// health
app.get('/health', (req, res) => res.json({ ok: true }));

// Register
app.post('/api/register', (req, res) => {
  const { name, email, password, dob, gender, addressInfo, country, state, tier, photo } = req.body || {};
  if(!name || !email || !password) return res.status(400).json({ error: 'Name, email and password are required' });
  const users = readUsers();
  const lower = String(email).toLowerCase();
  if(users.find(u => u.email === lower)) return res.status(400).json({ error: 'User already exists' });
  const user = {
    id: 'u_' + Date.now() + '_' + Math.random().toString(36).slice(2,8),
    name,
    email: lower,
    password, // plaintext for demo - replace with hashing in production
    dob: dob || null,
    gender: gender || null,
    addressInfo: addressInfo || null,
    country: country || null,
    state: state || null,
    role: 'user',
    tier: tier || 1,
    balances: { USD: 0.0, EUR: 0.0, GBP: 0.0 },
    transactions: [],
    walletAddress: 'AWL-' + Math.random().toString(36).slice(2,9).toUpperCase(),
    photo: photo || null,
    verified: true,
    cardLast4: ('' + Math.floor(1000 + Math.random() * 9000)).slice(-4),
    cardExpiry: '12/28',
    cardActivated: false,
    createdAt: new Date().toISOString()
  };
  users.push(user);
  writeUsers(users);
  const safe = { ...user }; delete safe.password;
  res.json({ success: true, user: safe });
});

// Login
app.post('/api/login', (req, res) => {
  const { email, password } = req.body || {};
  if(!email || !password) return res.status(400).json({ error: 'Email and password required' });
  const users = readUsers();
  const u = users.find(x => x.email === String(email).toLowerCase() && x.password === password);
  if(!u){
    // allow admin login with env vars
    if(process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD && String(email).toLowerCase() === String(process.env.ADMIN_EMAIL).toLowerCase() && password === process.env.ADMIN_PASSWORD){
      return res.json({ success: true, user: { email: process.env.ADMIN_EMAIL, role: 'admin' } });
    }
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const safe = { ...u }; delete safe.password;
  res.json({ success: true, user: safe });
});

// Admin: list users (protected by ADMIN_KEY header)
app.get('/api/users', (req, res) => {
  const key = req.headers['x-admin-key'];
  if(!process.env.ADMIN_KEY || key !== process.env.ADMIN_KEY){
    return res.status(401).json({ error: 'Unauthorized' });
  }
  const users = readUsers().map(u => { const c = { ...u }; delete c.password; return c; });
  res.json(users);
});

// Admin transfer (credit recipient) - protected
app.post('/api/admin/transfer', (req, res) => {
  const key = req.headers['x-admin-key'];
  if(!process.env.ADMIN_KEY || key !== process.env.ADMIN_KEY) return res.status(401).json({ error: 'Unauthorized' });
  const { recipientEmail, amount, currency, senderName, note } = req.body || {};
  if(!recipientEmail || !amount || !currency) return res.status(400).json({ error: 'recipientEmail, amount and currency required' });
  const users = readUsers();
  const recipient = users.find(u => u.email === String(recipientEmail).toLowerCase());
  if(!recipient) return res.status(404).json({ error: 'Recipient not found' });
  recipient.balances[currency] = (recipient.balances[currency] || 0) + Number(amount);
  recipient.transactions.unshift({ id: 'tx_'+Date.now(), type: 'Admin Credit', amount: Number(amount), currency, meta: note || 'Admin transfer', time: new Date().toISOString(), senderName: senderName || 'Admin' });
  writeUsers(users);
  res.json({ success: true, message: 'Transfer completed', recipient: { email: recipient.email, balances: recipient.balances } });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
